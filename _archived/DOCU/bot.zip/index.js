// index.js
const { Client, GatewayIntentBits, Partials, Collection, REST } = require('discord.js');
const fs   = require('fs');
const path = require('path');

const { loadFlaggedReviews, saveFlaggedReviews } = require('./lib/flaggedStore');
const { get } = require('./lib/scannerConfig');
const { getGuildConfig } = require('./lib/guildEnv');

/* ───── Config & Token ───── */
const cfg   = get();                 // komplette scanner-config.json (guilds-basiert)
const token = cfg.discordToken;      // ACHTUNG: sicher aufbewahren

/* ───── Client ───── */
const client = new Client({
  intents: [
    GatewayIntentBits.Guilds,
    GatewayIntentBits.GuildMessages,
    GatewayIntentBits.MessageContent,
    GatewayIntentBits.GuildMembers,
    GatewayIntentBits.GuildMessageReactions
  ],
  partials: [ Partials.Message, Partials.Channel, Partials.Reaction ]
});

/* REST-Helfer an den Client hängen */
client.rest    = new REST({ version: '10' }).setToken(token);
/* Config an Client hängen (für Thresholds etc.) */
client.config  = cfg;

/* ───── globale Maps ───── */
client.activeEvents   = new Map();
client.flaggedReviews = loadFlaggedReviews() || new Map();

/* ───── Persistenz ───── */
const persist = () => saveFlaggedReviews(client.flaggedReviews);
process.once('exit',   persist);
['SIGINT','SIGTERM'].forEach(sig => process.once(sig, () => { persist(); process.exit(0); }));

/* ───── Ordner für gelöschte Uploads ───── */
fs.mkdirSync(path.join(__dirname, 'deleted'), { recursive: true });

/* ───── Commands / Events laden ───── */
client.commands = new Collection();

for (const f of fs.readdirSync('./commands').filter(x => x.endsWith('.js'))) {
  const cmd = require(`./commands/${f}`);
  if (cmd?.name) client.commands.set(cmd.name, cmd);
}

for (const f of fs.readdirSync('./events').filter(x => x.endsWith('.js'))) {
  const evt = require(`./events/${f}`);
  if (evt?.name && typeof evt.execute === 'function') {
    const h = (...a) => evt.execute(...a, client);
    evt.once ? client.once(evt.name, h) : client.on(evt.name, h);
  }
}

/* ───── Sanity-Checks beim Start ───── */
client.once('ready', () => {
  const guilds = client.guilds.cache;
  for (const [gid] of guilds) {
    const gcfg = getGuildConfig(gid);
    if (!gcfg) {
      console.warn(`[config] Missing guilds[${gid}] in scanner-config.json – no mod-log / roles for this server.`);
      continue;
    }
    if (!gcfg.moderatorChannelIds || gcfg.moderatorChannelIds.length === 0) {
      console.warn(`[config] guilds[${gid}].moderatorChannelIds is empty – flags/deletes won't be announced.`);
    }
  }
  console.log(`[ok] Logged in as ${client.user.tag} · Guilds: ${guilds.size}`);
});

/* ───── Fehler-Logging (hilfreich bei Permissions/Fetch) ───── */
process.on('unhandledRejection', (err) => {
  console.warn('[unhandledRejection]', err?.message || err);
});
process.on('uncaughtException', (err) => {
  console.error('[uncaughtException]', err?.message || err);
});

/* ───── Login ───── */
client.login(token);
