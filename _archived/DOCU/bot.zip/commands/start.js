// /commands/start.js
const path = require('path');
const fs = require('fs');
const createStatsJson = require('../lib/createStatsJson');

module.exports = {
  name: 'start',

  async execute(message, client, args) {
    const parts = message.content.trim().split(/\s+/);
    parts.shift(); // remove !start
    if (parts.length < 3) {
      return message.reply('❌ Usage: `!start <tage> <uploads> <Event-Name>`');
    }

    const [tageStr, uploadsStr, ...nameParts] = parts;
    const days = parseInt(tageStr);
    const maxUploads = parseInt(uploadsStr);
    const eventName = nameParts.join(' ').trim();

    if (isNaN(days) || isNaN(maxUploads) || !eventName) {
      return message.reply('❌ Bitte gib gültige Werte an. Beispiel: `!start 2 2 Ghosts-and-Pizza`');
    }

    const guild = message.guild;
    const guildId = guild.id;
    const rawChannelName = eventName.toLowerCase().replace(/[^a-z0-9]+/g, '-').replace(/^-+|-+$/g, '');
    const existingChannel = guild.channels.cache.find(c => c.name === rawChannelName && c.type === 0);

    // Check for duplicate event name — nur innerhalb derselben Guild
    const activeEvents = client.activeEvents || new Map();
    for (const evt of activeEvents.values()) {
      if ((evt.name || '').toLowerCase() !== eventName.toLowerCase()) continue;
      const ch = client.channels.cache.get(evt.channel_id);
      if (ch?.guildId === guildId) {
        return message.reply(`⚠️ Es läuft bereits ein Event mit dem Namen "${eventName}" auf diesem Server.`);
      }
    }

    let targetChannel = existingChannel;
    if (!targetChannel) {
      try {
        targetChannel = await guild.channels.create({
          name: rawChannelName,
          type: 0,
          reason: `Event: ${eventName}`,
          permissionOverwrites: [
            {
              id: client.user.id,
              allow: ['ViewChannel', 'SendMessages', 'AddReactions']
            }
          ]
        });
        await message.reply(`📣 Created channel <#${targetChannel.id}> for the event.`);
      } catch (err) {
        console.error('❌ Channel creation failed:', err);
        return message.reply('❌ Could not create event channel.');
      }
    }

    const channelId = targetChannel.id;
    if (activeEvents.has(channelId)) {
      return message.reply('⚠️ In diesem Channel läuft bereits ein Event.');
    }

    const startTime = Date.now();
    const endTime = startTime + days * 24 * 60 * 60 * 1000;
    const unixEnd = Math.floor(endTime / 1000);
    const unixStart = Math.floor(startTime / 1000);

    // 🔒 Event-Ordner pro Guild trennen
    const eventFolder = path.join(__dirname, '..', 'event_files', guildId, rawChannelName);
    if (!fs.existsSync(eventFolder)) fs.mkdirSync(eventFolder, { recursive: true });

    const timeout = setTimeout(async () => {
      if (activeEvents.has(channelId)) {
        const event = activeEvents.get(channelId);
        const entryCount = event.entries.length;
        const userCount = event.users.size;

        await targetChannel.send(`🛑 **Event "${event.name}" ended!**\n✅ ${entryCount} entries by ${userCount} users.`);
        await createStatsJson(event, client);
        activeEvents.delete(channelId);
      }
    }, days * 24 * 60 * 60 * 1000);

    const newEvent = {
      name: eventName,
      start_time: startTime,
      end_time: endTime,
      folder: eventFolder,
      entries: [],
      users: new Set(),
      reactions: new Map(),
      remainingTimeout: timeout,
      channel_id: channelId,
      max_entries: maxUploads
    };

    activeEvents.set(channelId, newEvent);
    client.activeEvents = activeEvents;

    targetChannel.send(`🎉 **Event "${eventName}" gestartet!**\n📅 Endet: <t:${unixEnd}:f>  •  ⏳ <t:${unixEnd}:R>\n🖼 Max. Uploads pro User: \`${maxUploads}\``);
  }
};
