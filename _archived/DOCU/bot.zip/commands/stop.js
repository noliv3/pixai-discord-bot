// commands/stop.js
const path = require('path');
const fs = require('fs');
const createStatsJson = require('../lib/createStatsJson');
const scannerConfig = require('../lib/scannerConfig');

/**
 * Liefert alle Mod-Log-Channels der aktuellen Guild (strikter Guild-Match).
 * Unterstützt string ODER array in scanner-config.json (moderatorChannelId).
 */
function getModLogChannelsInGuild(client, guildId) {
  const cfg = scannerConfig.get();
  const raw = cfg.moderatorChannelId || [];
  const ids = Array.isArray(raw) ? raw : [raw];

  return ids
    .map(id => client.channels.cache.get(id))
    .filter(ch => ch?.isTextBased?.() && ch.guildId === guildId);
}

module.exports = {
  name: 'stop',

  async execute(message, client, args) {
    const channelId = message.channel.id;
    const activeEvents = client.activeEvents;

    if (!activeEvents || !activeEvents.has(channelId)) {
      return message.reply('❌ No active event in this channel.');
    }

    const event = activeEvents.get(channelId);
    const allFiles = fs.readdirSync(event.folder).filter(f =>
      ['.jpg', '.jpeg', '.png', '.webp'].includes(path.extname(f).toLowerCase())
    );

    const topEntries = allFiles
      .map(filename => {
        const match = filename.match(/_rate(\d+)_/);
        const score = match ? parseInt(match[1]) : 0;
        return { filename, score };
      })
      .sort((a, b) => b.score - a.score)
      .slice(0, 10);

    const resultText = [
      `📊 **Top 10 Results for Event "${event.name}"**\n`,
      ...topEntries.map((e, i) => `#${i + 1} – \`${e.filename}\` (⭐ ${e.score})`)
    ].join('\n');

    // 🔒 Nur Mod-Log-Channels dieser Guild benutzen
    const guildId = message.guild.id;
    const modChannels = getModLogChannelsInGuild(client, guildId);

    let delivered = false;

    // Versuche in allen passenden Mod-Log-Channels der Guild zu posten
    for (const ch of modChannels) {
      try {
        await ch.send(resultText);
        delivered = true;
      } catch (err) {
        console.error('[stop] failed to send to mod channel:', ch?.id, err.message);
      }
    }

    if (delivered) {
      await message.reply('✅ Toplist sent to the moderation channel.');
    } else {
      // Fallback: per DM an Command-Author
      try {
        const dm = await message.author.createDM();
        await dm.send(resultText);
        await message.reply('📬 Toplist sent to you via DM.');
      } catch (err) {
        await message.reply('⚠️ Could not send results (no mod-log in this guild and DM failed).');
        console.error('[stop] DM fallback failed:', err.message);
      }
    }

    await createStatsJson(event, client);
    activeEvents.delete(channelId);
  }
};
