# Wechsle ins Bot-Verzeichnis
Set-Location -Path "F:\discord\PixAI-BOT"

# Starte den Bot über Node.js
Write-Host "`nStarte PixAI Discord-Bot ..."
node index.js

# Halte das Fenster offen
Write-Host "`nBot wurde beendet. Drücke eine Taste zum Schließen..."
$null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
